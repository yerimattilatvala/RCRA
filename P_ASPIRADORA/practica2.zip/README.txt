Requerimientos:
    - Python versión 3.4.x o superior
    - Clingo.

Instrucciones de ejecución:
python VacuumCleaner.py ruta/roomX.txt

Salida:
	- Fichero dirtyRoom.txt por si se quiere ejecutar sin emplear el programa junto con las reglas que están en el fichero cleaner.txt .
    - Fichero output.txt con el resultado de ejecutar clingo.
    - Fichero vacuumCleanerSolution.txt con el cunjunto de movimientos realizados para alcanzar la meta.